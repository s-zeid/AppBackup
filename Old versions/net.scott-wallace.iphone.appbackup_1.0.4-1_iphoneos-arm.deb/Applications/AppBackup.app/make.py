#!/usr/bin/env python -OO
# Use this to compile AppBackup into optimized Python bytecode.  Resulting file
# is called App.pyo
import py_compile

py_compile.compile("App.py")
