# AppBackup
# An iPhoneOS application that backs up and restores the saved data and
# preferences of App Store apps.
#
# Copyright (C) 2008 Scott Wallace
# http://www.scott-wallace.net/iphone/appbackup
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
#
# Loosely based on Dave Arter's (dave@minus-zero.org) sample code from the
# iPhone/Python package.

# import some Python modules we'll use
import os, sys, tarfile, objc, time
from _uicaboodle import UIApplicationMain
# import some objc constants
from objc import YES, NO, NULL

# load UIKit
objc.loadBundle("UIKit", globals(), "/System/Library/Frameworks/UIKit.framework")

# the meat of the app
class PYApplication(UIApplication):
	# write the backup times to ~mobile/Library/AppBackup/backuptimes.plist
	def save_backuptimes_plist(self, init=False):
		if init == True:
			thedict = {}
		else:
			thedict = self.times_
		spam = NSDictionary.alloc().initWithDictionary_(thedict)
		spam.writeToFile_atomically_(self.backuptimesfile, NO)

	# get a dict from a .plist file (XML or binary)
	def plist(self, thefile):
		"""Uses iPhone frameworks to get a dict from a plist"""
		spam = NSDictionary.alloc().initWithContentsOfFile_(thefile)
		return dict(spam)

	# name is a misnomer:
	# makes a LIST where each item is a dict representing a given app
	# each dict has the name of a .app folder, a bundle ID (eg com.spam.app),
	# the path to the .app folder's parent directory, the app's GUID, the
	# display name, the time of last backup as a string, and the text to display
	# in the alertView that tells you when/if it was backed up.
	#
	# The list is sorted by friendly name.
	def make_app_dict(self):
		mobile = "/var/mobile"
		root = mobile+"/Applications"
		applist = []
		applist1 = []
		appdict = {}
		apps = os.listdir(root)
		self.all_bak = True
		self.any_bak = False
		for k in apps:
			appdir = root+"/"+k
			for j in os.listdir(appdir):
				if j.endswith(".app"):
					pl = self.plist("%s/%s/Info.plist" % (appdir, j))
					bundle = pl["CFBundleIdentifier"]
					if "CFBundleDisplayName" in pl:
						friendly = pl["CFBundleDisplayName"]
					else:
						friendly = j.rsplit(".app")[0]
					sortname = "%s_%s" % (friendly, bundle)

					if bundle in self.times_:
						baksec = time.localtime(float(self.times_[bundle]))
						bak = time.strftime("%a, %m/%d/%Y %I:%M %p", baksec)
						baktext = "Last backed up:  %s" % bak
						self.any_bak = True
					else:
						bak = None
						baktext = "Never backed up."
						self.all_bak = False

					mydict = {
						"name": j,
						"bundle": bundle,
						"path": appdir,
						"guid": k,
						"friendly": friendly,
						"bak": bak,
						"bak_text": baktext
					}
					applist1.append(sortname)
					appdict[sortname] = mydict
		applist1.sort()
		for i in applist1:
			applist.append(appdict[i])
		return applist

	# this backs up or restores a given app
	def act_on_app(self, app, action):
		path = app["path"]
		bundle = app["bundle"]
		tarpath = "%s/%s.tar.gz" % (self.tarballs, bundle)
		if action == "Backup":
			if os.path.exists(tarpath) != True:
				f = open(tarpath, "w")
				f.close()
			tar = tarfile.open(tarpath, "w:gz")
			tar.add(path+"/Documents", arcname="Documents")
			tar.add(path+"/Library", arcname="Library")
			tar.close()
			now = str(time.mktime(time.localtime()))
			self.times_[bundle] = now
			return True
		if action == "Restore":
			if os.path.exists(tarpath) == True:
				tar = tarfile.open(tarpath)
				tar.extractall(path)
				tar.close()
				return True
			else:
				return False

	# how many rows the table will have
	@objc.signature("i@:@")
	def numberOfRowsInTable_(self, table):
		return len(self.apps_)

	# the table calls this to get the row contents for each row
	@objc.signature("@@:@i@@")
	def table_cellForRow_column_reusing_(self, table, row, col, reusing):
		app = self.apps_[row]
		if reusing is not None:
			cell = reusing
		else:
			cell = UIImageAndTextTableCell.alloc().init()

		# instead of doing cell.setTitle_ we're going to make 2
		# UITextLabels, one with the friendly name and the other with
		# the last backup time.  This is b/c I want to show both of
		# these to the user in a prettier way.  Also make a blank label
		# to go underneath them to prevent artifacts while scrolling.
		# The downside is that the row color doesn't change when selected.

		# Label 0 (the blank one to prevent artifacts)
		# Positioned at top-left of row
		# White background
		# 320px wide, 67px (row height - 1) high
		label0rect = ((0, 0), (320, 67))
		label0 = UITextLabel.alloc().initWithFrame_(label0rect)
		label0.setBackgroundColor_(UIColor.whiteColor())
		cell.addSubview_(label0)

		# Label 1
		# System font, bold, 20px, black
		# Clear background; positioned at 10, 8 from top-left of label0
		# 300px wide, 25px high
		label1rect = ((10, 8), (300, 25))
		font1 = UIFont.boldSystemFontOfSize_(20)
		label1 = UITextLabel.alloc().initWithFrame_(label1rect)
		label1.setFont_(font1)
		label1.setColor_(UIColor.blackColor())
		label1.setBackgroundColor_(UIColor.clearColor())
		label1.setText_(app["friendly"])
		label0.addSubview_(label1)

		# Label 2
		# System font, normal weight, 14px, gray
		# Clear background; positioned at 10, 38 from top-left of label0
		# 300px wide, 20 px high
		label2rect = ((10, 38), (300, 20))
		font2 = UIFont.systemFontOfSize_(14)
		label2 = UITextLabel.alloc().initWithFrame_(label2rect)
		label2.setFont_(font2)
		label2.setColor_(UIColor.grayColor())
		label2.setBackgroundColor_(UIColor.clearColor())
		label2.setText_(app["bak_text"])
		label0.addSubview_(label2)

		return cell

	# what to do when a table row is selected
	@objc.signature("v@:@@")
	def tableRowSelected_(self, notification, spam):
		obj = notification.object()
		cell = obj.cellAtRow_column_(obj.selectedRow(), 0)
		cell.setSelected_withFade_(False, True)
		self.current_app = obj.selectedRow()
		app = self.apps_[self.current_app]
		alert = UIAlertView.alloc().init()
		alert.setTitle_(app["friendly"])
		alert.setDelegate_(self)
		backup = alert.addButtonWithTitle_("Backup")
		if app["bak"] != None:
			restore = alert.addButtonWithTitle_("Restore")
			prompt = "Do you want to backup or restore this app?"
		else:
			prompt = "Do you want to backup this app?"
		cancel = alert.addButtonWithTitle_("Cancel")
		alert.setCancelButtonIndex_(cancel)
		alert.setBodyText_(prompt)
		alert.show()

	# what to do when you click a navbar button
	@objc.signature("v@:@i")
	def navigationBar_buttonClicked_(self, bar, button):
		if button == 0:
			alert = UIAlertView.alloc().init()
			alert.setTitle_(self.about_title)
			alert.setDelegate_(self)
			alert.setBodyText_(self.about_text)
			web = alert.addButtonWithTitle_("Web Site")
			cancel = alert.addButtonWithTitle_("OK")
			alert.setCancelButtonIndex_(cancel)
			alert.show()
		if button == 1:
			alert = UIAlertView.alloc().init()
			alert.setTitle_("All Applications")
			backup = alert.addButtonWithTitle_("Backup")
			if self.any_bak == True:
				text = "Do you want to backup or restore all apps?"
				restore = alert.addButtonWithTitle_("Restore")
			else:
				text = "Do you want to backup all apps?"
			alert.setBodyText_(text)
			alert.setDelegate_(self)
			cancel = alert.addButtonWithTitle_("Cancel")
			alert.setCancelButtonIndex_(cancel)
			alert.show()

	# what to do when you close an alert box
	@objc.signature("v@:@i")
	def alertView_didDismissWithButtonIndex_(self, malert, index):
		action = malert.buttonTitleAtIndex_(index)
		if malert.title() == self.about_title:
			if action != "OK":
				url = NSURL.alloc().initWithString_(self.web_site)
				UIApplication.sharedApplication().openURL_(url)
				sys.exit()
		elif malert.title() == "All Applications":
			if action != "Cancel":
				# We're using a UIModalView so it doesn't show
				# the space where buttons go (we have no buttons)
				alert = UIModalView.alloc().init()
				alert.setTitle_("Please wait...")
				if action == "Backup":
					text = "Backing up all apps..."
					text2 = "Backed up all apps!"
					text3 = "The following apps could not be backed up:"
				if action == "Restore":
					text = "Restoring all apps..."
					text2 = "Restored all apps!"
					text3 = "The following apps could not be restored:"
				alert.setBodyText_(text)
				alert.popupAlertAnimated_(YES)
				alldone = True
				failed = []
				for app in self.apps_:
					if action == "Backup":
						ret = self.act_on_app(app, "Backup")
						if ret != True:
							alldone = False
							failed.append(app["friendly"])
					elif action == "Restore" and app["bak"] != None:
						ret = self.act_on_app(app, "Restore")
						if ret != True:
							alldone = False
							failed.append(app["friendly"])
				if action == "Backup":
					self.save_backuptimes_plist()
					del self.apps_
					self.apps_ = self.make_app_dict()
					self.list.reloadData()
				alert.dismiss()
				if alldone == True:
					donetext = "Done!"
					use = text2
				else:
					donetext = "%s failed" % action
					failedstring = "\n".join(failed)
					use = "%s\n\n%s" % (text3, failedstring)
				alert2 = UIAlertView.alloc().init()
				alert2.setTitle_(donetext)
				alert2.setBodyText_(use)
				alert2.addButtonWithTitle_("OK")
				alert2.show()
		else:
			app = self.apps_[self.current_app]
			if action != "Cancel":
				# We're using a UIModalView so it doesn't show
				# the space where buttons go (we have no buttons)
				alert = UIModalView.alloc().init()
				alert.setTitle_("Please wait...")
				if action == "Backup":
					text = "Backing up %s..." % app["friendly"]
					text2 = "Backed up %s!" % app["friendly"]
					text3 = "The app %s could not be backed up." % app["friendly"]
				if action == "Restore":
					text = "Restoring %s..." % app["friendly"]
					text2 = "Restored %s!" % app["friendly"]
					text3 = "The app %s could not be restored." % app["friendly"]
				alert.setBodyText_(text)
				alert.popupAlertAnimated_(YES)
				if action == "Backup":
					ret = self.act_on_app(app, "Backup")
					if ret == True:
						self.save_backuptimes_plist()
						del self.apps_
						self.apps_ = self.make_app_dict()
						self.list.reloadData()
						donetext = "Done!"
						use = text2
					else:
						donetext = "Backup failed"
						use = text3
				if action == "Restore":
					ret = self.act_on_app(app, "Restore")
					if ret == True:
						donetext = "Done!"
						use = text2
					else:
						donetext = "Restore failed"
						use = text3
				alert.dismiss()
				alert2 = UIAlertView.alloc().init()
				alert2.setTitle_(donetext)
				alert2.setBodyText_(use)
				alert2.addButtonWithTitle_("OK")
				alert2.show()
			self.current_app = None

	@objc.signature("v@:@")
	def applicationDidFinishLaunching_(self, unused):
		# initialize a bunch of variables used in various parts of the app
		self.script = sys.argv[0]
		self.myname = "AppBackup"
		self.about_title = "About %s" % (self.myname)
		textfo = open("%s/CREDITS.txt" % os.path.dirname(self.script))
		self.about_text = unicode(textfo.read(), encoding="utf_8_sig")
		textfo.close()
		self.web_site = "http://www.scott-wallace.net/iphone/appbackup"
		self.libroot = "/var/mobile/Library/AppBackup"
		self.tarballs = self.libroot+"/tarballs"
		self.backuptimesfile = self.libroot+"/backuptimes.plist"
		if os.path.exists(self.libroot) != True:
			os.mkdir(self.libroot)
		if os.path.exists(self.tarballs) != True:
			os.mkdir(self.tarballs)
		if os.path.exists(self.backuptimesfile) != True:
			self.save_backuptimes_plist(True)

		self.times_ = self.plist(self.backuptimesfile)
		self.apps_ = self.make_app_dict()

		# make window
		outer = UIHardware.fullScreenApplicationContentRect()
		self.window = UIWindow.alloc().initWithFrame_(outer)
		self.window.orderFront_(self)
		self.window.makeKey_(self)
		self.window.setHidden_(NO)
		inner = self.window.bounds()
		navsize = UINavigationBar.defaultSize()
		navrect = ((0, 0), (inner[1][0], navsize[1]))
		self.view = UIView.alloc().initWithFrame_(self.window.bounds())
		self.window.setContentView_(self.view)

		# make navbar and add buttons
		self.navbar = UINavigationBar.alloc().initWithFrame_(navrect);
		self.navbar.setBarStyle_(0)
		navitem = UINavigationItem.alloc().initWithTitle_("App Store Apps")
		self.navbar.pushNavigationItem_(navitem)
		self.navbar.showLeftButton_withStyle_rightButton_withStyle_(
			"All", 0,
			"About", 0
		)
		self.navbar.setDelegate_(self)
		self.view.addSubview_(self.navbar)

		# make table column and table, and add column to table
		col = UITableColumn.alloc().initWithTitle_identifier_width_("Name", "name", 320)
		lower = ((0, navsize[1]), (inner[1][0], inner[1][1] - navsize[1]));
		self.list = UITable.alloc().initWithFrame_(lower)
		self.list.setSeparatorStyle_(1)
		self.list.addTableColumn_(col)
		self.list.setReusesTableCells_(YES)
		self.list.setDelegate_(self)
		self.list.setRowHeight_(68)
		self.list.setDataSource_(self)
		self.view.addSubview_(self.list)
		self.list.reloadData()

# and let's start 'er up!
UIApplicationMain(sys.argv, PYApplication)
