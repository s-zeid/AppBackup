# AppBackup
# An iPhoneOS application that backs up and restores the saved data and
# preferences of App Store apps.
#
# Copyright (C) 2008-2009 Scott Wallace
# http://www.scott-wallace.net/iphone/appbackup
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
#
# Loosely based on Dave Arter's (dave@minus-zero.org) sample code from the
# iPhone/Python package.

# NB:  Starting with version 1.0.3, this file is compiled into optimized Python
# bytecode, and that bytecode is executed instead of this file.  For your
# convenience, a script called make.sh is included that will do that for you:
#  /Applications/AppBackup.app# ./make.sh

# import some Python modules we'll use
import ctypes, objc, os, pyuca, sys, tarfile, time
from _uicaboodle import UIApplicationMain
# import some objc constants
from objc import YES, NO, NULL

# set working directory to AppBackup.app's location
os.chdir(os.path.dirname(sys.argv[0]))

# load UIKit
objc.loadBundle("UIKit", globals(), "/System/Library/Frameworks/UIKit.framework")

# load MobileSubstrate
if os.path.isfile("/Library/MobileSubstrate/MobileSubstrate.dylib"):
 mobileSubstrateDylib = ctypes.cdll.LoadLibrary("/Library/MobileSubstrate/MobileSubstrate.dylib")
 mobileSubstrateDylib.MSInitialize()

# set up pyuca
ucaCollator = pyuca.Collator("uca_allkeys.txt")

# the meat of the app
class AppBackup(UIApplication):
 # get a localizable string from LANGUAGE.lproj/Localizable.strings
 def string(self, s):
  return unicode(NSBundle.mainBundle().localizedStringForKey_value_table_(s, "", None))

 # takes a UNIX timestamp and makes it a string formatted according to
 # the device's locale and user preferences
 def localized_date(self, d):
  date = time.strftime("%Y-%m-%d %H:%M:%S", d)
  dateformat = NSDateFormatter.alloc().init()
  dateformat.setDateFormat_("yyyy-MM-dd HH:mm:ss")
  date2 = dateformat.dateFromString_(date)
  dateformat2 = NSDateFormatter.alloc().init()
  dateformat2.setDateStyle_(2)
  dateformat2.setTimeStyle_(1)
  return dateformat2.stringFromDate_(date2)

 # write the backup times to ~mobile/Library/AppBackup/backuptimes.plist
 def save_backuptimes_plist(self, init=False):
  if init == True:
   thedict = {}
  else:
   thedict = self.times_
  spam = NSDictionary.alloc().initWithDictionary_(thedict)
  spam.writeToFile_atomically_(self.backuptimesfile, NO)

 # get a dict from a .plist file (XML or binary)
 def plist(self, thefile):
  spam = NSDictionary.alloc().initWithContentsOfFile_(thefile)
  return spam

 # name is a misnomer:
 # makes a LIST where each item is a dict representing a given app
 # each dict has the name of a .app folder, a bundle ID (e.g. com.spam.app),
 # the path to the .app folder's parent directory, the app's GUID, the
 # display name, the possessive form of the display name,  the time of
 # the last backup as a string, the text to display in the table that
 # tells you when/if it was backed up, and whether the app is useable
 # (not corrupted) or not.
 #
 # The list is sorted by friendly name, then by bundle ID.
 def make_app_dict(self):
  mobile = u"/var/mobile"
  root = mobile+"/Applications"
  applist = []
  applist1 = []
  appdict = {}
  apps1 = os.listdir(root)
  apps = []
  for i in apps1:
   if os.path.isdir(root+"/"+i) == True:
    apps.append(i)
  self.all_bak = True
  self.any_bak = False
  self.any_corrupted = False
  if self.apps_probed == False:
   # Debug text; do not translate
   print "Here are the app bundles and Info.plist's I found:"
  for k in apps:
   appdir = root+"/"+k
   for j in os.listdir(appdir):
    if j.endswith(u".app"):
     plistfile = u"%s/%s/Info.plist" % (appdir, j)
     if self.apps_probed == False:
      # More debug text
      print u"%s:  %s" % (j.encode('utf8', 'replace').__repr__(), plistfile.split(root+"/", 1)[1].encode('utf8', 'replace').__repr__())
     if os.path.exists(plistfile) == True:
      pl = self.plist(plistfile)
      bundle = pl["CFBundleIdentifier"]
      if "CFBundleDisplayName" in pl:
       friendly = pl["CFBundleDisplayName"]
       if friendly == "":
        friendly = j.rsplit(u".app", 1)[0]
      else:
       friendly = j.rsplit(u".app", 1)[0]
      sortname = u"%s_%s" % (friendly.lower(), bundle)
      useable = True

      if bundle in self.times_:
       baksec = time.localtime(float(self.times_[bundle]))
       bak = self.localized_date(baksec)
       baktext = self.string("baktext_yes") % bak
       self.any_bak = True
      else:
       bak = None
       baktext = self.string("baktext_no")
       self.all_bak = False
     else:
      self.any_corrupted = True
      friendly = j.rsplit(u".app", 1)[0]
      bundle = "invalid.appbackup.corrupted"
      sortname = u"%s_%s" % (friendly, bundle)
      bak = None
      baktext = self.string("app_corrupted_list")
      useable = False

     if self.plural_last != "" and friendly[-1] == self.plural_last:
      possessive = self.string("plural_possessive") % friendly
     else:
      possessive = self.string("singular_possessive") % friendly

     mydict = {
      "name": j,
      "bundle": bundle,
      "path": appdir,
      "guid": k,
      "friendly": friendly,
      "possessive": possessive,
      "bak": bak,
      "bak_text": baktext,
      "useable": useable
     }
     applist1.append(sortname)
     appdict[sortname] = mydict
  applist1.sort(key=pyucaCollator.sort_key)
  for i in applist1:
   applist.append(appdict[i])
  return applist

 # this backs up or restores a given app
 def act_on_app(self, app, action):
  if app["useable"] == False:
   return False
  path = app["path"]
  bundle = app["bundle"]
  tarpath = "%s/%s.tar.gz" % (self.tarballs, bundle)
  if action == "Backup":  # Internal string; don't translate
   if os.path.exists(tarpath) != True:
    f = open(tarpath, "w")
    f.close()
   tar = tarfile.open(tarpath, "w:gz")
   tar.add(path+"/Documents", arcname="Documents")
   tar.add(path+"/Library", arcname="Library")
   tar.close()
   now = str(time.mktime(time.localtime()))
   self.times_[bundle] = now
   return True
  if action == "Restore":  # Internal string; don't translate
   if os.path.exists(tarpath) == True:
    tar = tarfile.open(tarpath)
    tar.extractall(path)
    tar.close()
    return True
   else:
    return False

 # how many rows the table will have
 @objc.signature("i@:@")
 def numberOfRowsInTable_(self, table):
  return len(self.apps_)

 # the table calls this to get the row contents for each row
 @objc.signature("@@:@i@@")
 def table_cellForRow_column_reusing_(self, table, row, col, reusing):
  app = self.apps_[row]
  if reusing is not None:
   cell = reusing
  else:
   cell = UIImageAndTextTableCell.alloc().init()

  # instead of doing cell.setTitle_ we're going to make 2
  # UITextLabels, one with the friendly name and the other with
  # the last backup time.  This is b/c I want to show both of
  # these to the user in a prettier way.  Also make a blank label
  # to go underneath them to prevent artifacts while scrolling.
  # The downside is that the row color doesn't change when selected.

  # Label 0 (the blank one to prevent artifacts)
  # Positioned at top-left of row
  # White background
  # 320px wide, 67px (row height - 1) high
  label0rect = ((0, 0), (320, 67))
  label0 = UITextLabel.alloc().initWithFrame_(label0rect)
  label0.setBackgroundColor_(UIColor.whiteColor())
  cell.addSubview_(label0)

  # Label 1
  # System font, bold, 20px, black if valid, gray if not
  # Clear background; positioned at 10, 8 from top-left of label0
  # 300px wide, 25px high
  label1rect = ((10, 8), (300, 25))
  font1 = UIFont.boldSystemFontOfSize_(20)
  label1 = UITextLabel.alloc().initWithFrame_(label1rect)
  label1.setFont_(font1)
  if app["useable"] == True:
   label1.setColor_(UIColor.blackColor())
  else:
   label1.setColor_(UIColor.grayColor())
  label1.setBackgroundColor_(UIColor.clearColor())
  label1.setText_(app["friendly"])
  label0.addSubview_(label1)

  # Label 2
  # System font, normal weight, 14px, gray
  # Clear background; positioned at 10, 38 from top-left of label0
  # 300px wide, 20 px high
  label2rect = ((10, 38), (300, 20))
  font2 = UIFont.systemFontOfSize_(14)
  label2 = UITextLabel.alloc().initWithFrame_(label2rect)
  label2.setFont_(font2)
  label2.setColor_(UIColor.grayColor())
  label2.setBackgroundColor_(UIColor.clearColor())
  label2.setText_(app["bak_text"])
  label0.addSubview_(label2)

  return cell

 # what to do when a table row is selected
 @objc.signature("v@:@@")
 def tableRowSelected_(self, notification, spam):
  obj = notification.object()
  cell = obj.cellAtRow_column_(obj.selectedRow(), 0)
  cell.setSelected_withFade_(False, True)
  self.current_app = obj.selectedRow()
  app = self.apps_[self.current_app]
  alert = UIActionSheet.alloc().init()
  alert.setTitle_(app["friendly"])
  alert.setDelegate_(self)
  if app["useable"] == False:
   prompt = self.string("app_corrupted_prompt")
   canceltext = self.string("ok")
  elif app["bak"] != None:
   backup = alert.addButtonWithTitle_(self.string("backup"))
   restore = alert.addButtonWithTitle_(self.string("restore"))
   prompt = self.string("backup_restore_1_app")
   canceltext = self.string("cancel")
  else:
   backup = alert.addButtonWithTitle_(self.string("backup"))
   prompt = self.string("backup_1_app")
   canceltext = self.string("cancel")
  cancel = alert.addButtonWithTitle_(canceltext)
  alert.setCancelButtonIndex_(cancel)
  alert.setBodyText_(prompt)
  alert.popupAlertAnimated_(YES)

 # what to do when you click a navbar button
 @objc.signature("v@:@i")
 def navigationBar_buttonClicked_(self, bar, button):
  if button == 0:  # About screen
   alert = UIActionSheet.alloc().init()
   alert.setTitle_(self.about_title)
   alert.setDelegate_(self)
   alert.setBodyText_(self.about_text)
   web = alert.addButtonWithTitle_(self.string("web_site"))
   cancel = alert.addButtonWithTitle_(self.string("ok"))
   alert.setCancelButtonIndex_(cancel)
   alert.popupAlertAnimated_(YES)
  if button == 1:  # Backup/restore all apps
   alert = UIActionSheet.alloc().init()
   alert.setTitle_(self.string("all_apps"))
   backup = alert.addButtonWithTitle_(self.string("backup"))
   if self.any_bak == True:
    text = self.string("backup_restore_all_apps")
    restore = alert.addButtonWithTitle_(self.string("restore"))
   else:
    text = self.string("backup_all_apps")
   alert.setBodyText_(text)
   alert.setDelegate_(self)
   cancel = alert.addButtonWithTitle_(self.string("cancel"))
   alert.setCancelButtonIndex_(cancel)
   alert.popupAlertAnimated_(YES)

 # what to do when you close an alert box
 @objc.signature("v@:@i")
 def actionSheet_didDismissWithButtonIndex_(self, malert, index):
  action = malert.buttonTitleAtIndex_(index)
  if malert.title() == self.about_title:
   if action == self.string("web_site"):
    url = NSURL.alloc().initWithString_(self.web_site)
    UIApplication.sharedApplication().openURL_(url)
    sys.exit()
  elif malert.title() == self.string("all_apps"):
   if action != self.string("cancel"):
    # We're using a UIModalView so it doesn't show
    # the space where buttons go (we have no buttons)
    alert = UIModalView.alloc().init()
    alert.setTitle_(self.string("please_wait"))
    if action == self.string("backup"):
     text = self.string("all_status_backup_doing")
     text2 = self.string("all_status_backup_done")
     text3 = self.string("all_status_backup_failed")
     text4 = self.string("all_status_backup_corrupted")
     alldonetext = self.string("backup_done")
     allpartdonetext = self.string("backup_partially_done")
    if action == self.string("restore"):
     text = self.string("all_status_restore_doing")
     text2 = self.string("all_status_restore_done")
     text3 = self.string("all_status_restore_failed")
     text4 = self.string("all_status_restore_corrupted")
     alldonetext = self.string("restore_done")
     allpartdonetext = self.string("restore_partially_done")
    alert.setBodyText_(text)
    alert.popupAlertAnimated_(YES)
    alldone = True
    failed = []
    corrupted = []
    any_corrupted = False
    for app in self.apps_:
     if app["useable"] == True:
      if action == self.string("backup"):
       ret = self.act_on_app(app, "Backup")
       if ret != True:
        alldone = False
        failed.append(app["friendly"])
      elif action == self.string("restore") and app["bak"] != None:
       ret = self.act_on_app(app, "Restore")
       if ret != True:
        alldone = False
        failed.append(app["friendly"])
     else:
      any_corrupted = True
      corrupted.append(app["friendly"])
      failed.append(app["friendly"] + " (corrupted)")
    if action == self.string("backup"):
     self.save_backuptimes_plist()
     del self.apps_
     self.apps_ = self.make_app_dict()
     self.list.reloadData()
    alert.dismiss()
    if alldone == True and any_corrupted == False:
     donetext = alldonetext
     use = text2
    elif alldone == True and any_corrupted == True:
     donetext = allpartdonetext
     corruptedstring = "\n".join(corrupted)
     use = "%s\n\n%s" % (text4, corruptedstring)
    else:
     donetext = allpartdonetext
     failedstring = "\n".join(failed)
     use = "%s\n\n%s" % (text3, failedstring)
    alert.dismiss()
    alert2 = UIAlertView.alloc().init()
    alert2.setTitle_(donetext)
    alert2.setBodyText_(use)
    alert2.addButtonWithTitle_(self.string("ok"))
    alert2.show()
  else:
   app = self.apps_[self.current_app]
   if action != self.string("cancel") and action != self.string("ok"):
    # We're using a UIModalView so it doesn't show
    # the space where buttons go (we have no buttons)
    alert = UIModalView.alloc().init()
    alert.setTitle_(self.string("please_wait"))
    if action == self.string("backup"):
     text = self.string("1_status_backup_doing") % app["possessive"]
     text2 = self.string("1_status_backup_done") % app["possessive"]
     text3 = self.string("1_status_backup_failed") % app["possessive"]
    if action == self.string("restore"):
     text = self.string("1_status_restore_doing") % app["possessive"]
     text2 = self.string("1_status_restore_done") % app["possessive"]
     text3 = self.string("1_status_restore_failed") % app["possessive"]
    alert.setBodyText_(text)
    alert.popupAlertAnimated_(YES)
    if action == self.string("backup"):
     ret = self.act_on_app(app, "Backup")
     if ret == True:
      self.save_backuptimes_plist()
      del self.apps_
      self.apps_ = self.make_app_dict()
      self.list.reloadData()
      donetext = self.string("backup_done")
      use = text2
     else:
      donetext = self.string("backup_failed")
      use = text3
    if action == self.string("restore"):
     ret = self.act_on_app(app, "Restore")
     if ret == True:
      donetext = self.string("restore_done")
      use = text2
     else:
      donetext = self.string("restore_failed")
      use = text3
    alert.dismiss()
    alert2 = UIAlertView.alloc().init()
    alert2.setTitle_(donetext)
    alert2.setBodyText_(use)
    alert2.addButtonWithTitle_(self.string("ok"))
    alert2.show()
   self.current_app = None

 @objc.signature("v@:@")
 def applicationDidFinishLaunching_(self, unused):
  # initialize a bunch of variables used in various parts of the app
  self.apps_probed = False
  self.script = sys.argv[0]
  self.myname = "AppBackup"
  self.version = "1.0.4"
  print "%s version %s" % (self.myname, self.version)
  self.about_title = self.string("about_title") % self.myname
  self.plural_last = self.string("plural_last_letter")
  # Credits are English only for now
  textfo = open("%s/CREDITS.txt" % os.path.dirname(self.script))
  self.about_text = unicode(textfo.read(), encoding="utf_8_sig")
  textfo.close()
  self.web_site = "http://www.scott-wallace.net/iphone/appbackup"
  self.libroot = "/var/mobile/Library/AppBackup"
  self.tarballs = self.libroot+"/tarballs"
  self.backuptimesfile = self.libroot+"/backuptimes.plist"
  if os.path.exists(self.libroot) != True:
   os.mkdir(self.libroot)
  if os.path.exists(self.tarballs) != True:
   os.mkdir(self.tarballs)
  if os.path.exists(self.backuptimesfile) != True:
   self.save_backuptimes_plist(True)

  # make window
  outer = UIHardware.fullScreenApplicationContentRect()
  self.window = UIWindow.alloc().initWithFrame_(outer)
  self.window.orderFront_(self)
  self.window.makeKey_(self)
  self.window.setHidden_(NO)
  inner = self.window.bounds()
  navsize = UINavigationBar.defaultSize()
  navrect = ((0, 0), (inner[1][0], navsize[1]))
  navrect2 = ((0, inner[1][1] - navsize[1]), (inner[1][0], navsize[1]))
  navrect3 = ((0, inner[1][1] - navsize[1] + 1), (inner[1][0], navsize[1]))
  self.view = UIView.alloc().initWithFrame_(inner)
  self.window.setContentView_(self.view)

  # make navbar 1 with title only
  self.navbar = UINavigationBar.alloc().initWithFrame_(navrect);
  self.navbar.setBarStyle_(0)
  navitem = UINavigationItem.alloc().initWithTitle_(self.string("main_window_title"))
  self.navbar.pushNavigationItem_(navitem)
  self.navbar.setDelegate_(self)
  self.view.addSubview_(self.navbar)

  # draw a UIToolbar under navbar 2 for cosmetic purposes
  self.toolbar = UIToolbar.alloc().initWithFrame_(navrect2)
  self.view.addSubview_(self.toolbar)

  # make table column and table, and add column to table
  col = UITableColumn.alloc().initWithTitle_identifier_width_("Name", "name", 320)
  lower = ((0, navsize[1]), (inner[1][0], inner[1][1] - (navsize[1] * 2)));
  self.list = UITable.alloc().initWithFrame_(lower)
  self.list.setSeparatorStyle_(1)
  self.list.addTableColumn_(col)
  self.list.setReusesTableCells_(YES)
  self.list.setDelegate_(self)
  self.list.setRowHeight_(68)
  self.view.addSubview_(self.list)

  # show a HUD while we load the app list
  self.hud = UIProgressHUD.alloc().initWithWindow_(self.window)
  self.hud.setText_(self.string("please_wait"))
  self.hud.show_(YES)

  # keep the ***damn phone from killing AppBackup if it takes too
  # long to find apps!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  #self.reportAppLaunchFinished()

  # find AppStore apps for the 1st time
  self.times_ = dict(self.plist(self.backuptimesfile))
  self.apps_ = self.make_app_dict()
  self.apps_probed = True
  self.hud.show_(NO)

  # make navbar 2 and add buttons
  self.navbar2 = UINavigationBar.alloc().initWithFrame_(navrect3);
  self.navbar2.setBarStyle_(0)
  self.navbar2.showLeftButton_withStyle_rightButton_withStyle_(
   self.string("all_button"), 0,
   self.string("about_button"), 0
  )
  self.navbar2.setDelegate_(self)
  self.view.addSubview_(self.navbar2)

  # update the list and get rolling!
  self.list.setDataSource_(self)
  self.list.reloadData()

# and let's start 'er up!
UIApplicationMain(sys.argv, AppBackup)
