class PListError(Exception):
    pass

class CFFormatError(Exception):
    pass